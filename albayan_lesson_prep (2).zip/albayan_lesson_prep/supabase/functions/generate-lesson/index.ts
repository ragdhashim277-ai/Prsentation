// Supabase Edge Function: يولّد خطة درس بواسطة Claude.
// النشر:  supabase functions deploy generate-lesson
// المفتاح: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
// (اختياري) supabase secrets set CLAUDE_MODEL=claude-sonnet-5-5

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}

const clip = (v: unknown, n: number) =>
  typeof v === "string" ? v.trim().slice(0, n) : "";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  try {
    const body = await req.json();
    const title = clip(body.title, 200);
    const subject = clip(body.subject, 60);
    const level = clip(body.level, 30);
    const grade = clip(body.grade, 30);
    const notes = clip(body.notes, 6000);

    if (!title) return json({ error: "title is required" }, 400);

    const apiKey = Deno.env.get("ANTHROPIC_API_KEY");
    if (!apiKey) return json({ error: "server not configured" }, 500);

    const isEnglish = subject === "اللغة الإنجليزية";
    const lang = isEnglish
      ? "English (with short Arabic headings in parentheses)"
      : "العربية الفصحى المبسطة";

    const system =
      `أنت مستشار تربوي خبير تساعد معلمين في السودان على تحضير دروسهم. ` +
      `اكتب خطة درس عملية بلغة: ${lang}. ` +
      `استخدم نصاً عادياً فقط بدون رموز تنسيق مثل # أو * أو ** لأن النص سيُقرأ صوتياً. ` +
      `افصل الأقسام بسطر فارغ، وابدأ كل قسم بعنوانه متبوعاً بنقطتين، بهذا الترتيب: ` +
      `أهداف الدرس، التمهيد، الشرح، النشاط، التقويم، الواجب. ` +
      `اجعل الشرح مفصلاً بأمثلة مناسبة للمستوى.`;

    const prompt =
      `المادة: ${subject}\nالمرحلة: ${level}\nالصف: ${grade}\nعنوان الدرس: ${title}` +
      (notes ? `\n\nملاحظات المعلم (ابنِ عليها):\n${notes}` : "");

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: Deno.env.get("CLAUDE_MODEL") ?? "claude-sonnet-5-5",
        max_tokens: 2500,
        system,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!r.ok) {
      console.error("anthropic error", r.status, await r.text());
      return json({ error: "generation failed" }, 502);
    }

    const data = await r.json();
    const content = (data.content ?? [])
      .filter((b: { type: string }) => b.type === "text")
      .map((b: { text: string }) => b.text)
      .join("\n")
      .trim();

    if (!content) return json({ error: "empty response" }, 502);
    return json({ content });
  } catch (e) {
    console.error(e);
    return json({ error: "bad request" }, 400);
  }
});
